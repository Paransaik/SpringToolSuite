package com.example.spring01.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.spring01.model.dto.ProductDTO;

@Controller
public class MainController {
	private static final Logger logger=
			LoggerFactory.getLogger(MainController.class);
	
	@RequestMapping("/")
	public String main(Model model) {
		model.addAttribute("message","홈페이지 방문을 환영합니다.");
		return "main";
	}
	
	@RequestMapping(value="gugu.do", method = RequestMethod.GET)
	public String gugu(int dan, Model model) {
		
		//int dan = 7;
		String result = "";
		for(int i = 1; i <= 9; i++) {
			result += dan + "x" + i + "=" + dan * i + "<br>";
		}
		model.addAttribute("result", result);
		return "test/gugu";
	}
	
	@RequestMapping("test")
	public void test() {
	}
	
	@RequestMapping("test/doA")
	public String doA(Model model) {
		logger.info("doA called...");
		model.addAttribute("message","홈페이지 방문을 환영합니다.");
		return "test/doB";
	}
	
	@RequestMapping("test/doB")
	public String doB(Model model) {
		logger.info("doB called...");
		model.addAttribute("message","홈페이지 방문을 환영합니다.");
		return "test/doB";
	}
	//객체를 전달, 값 하나밖에 못 보냄
	@RequestMapping("test/doC")
	public ModelAndView doC() {
		Map<String,Object> map = new HashMap<>();
		map.put("product", new ProductDTO("샤프", 1000));
		return new ModelAndView("test/doC","map", map);	
	}
	
	@RequestMapping("test/doD")
	public String doD() {
		return "redirect:/test/doE"; // 포워드
		//retrun "redirect:/hello.jsp
	}
	
	@RequestMapping("test/doE")
	public void doE() {
		//doE.jsp로 포워드
	}

}
