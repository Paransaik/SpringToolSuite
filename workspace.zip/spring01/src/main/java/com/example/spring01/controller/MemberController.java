package com.example.spring01.controller;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.spring01.model.dto.MemberDTO;
import com.example.spring01.service.MemberService;

@Controller
public class MemberController {
	private static final Logger logger=
			LoggerFactory.getLogger(MemberController.class);
	
	@Inject // MemberService 객체가 주입됨
	MemberService memberService;
	
	@RequestMapping("member/list.do")
	public String memberList(Model model){
		List<MemberDTO> list = memberService.memberList();
		logger.info("회원 목록:"+list);
		model.addAttribute("list", list);
		return "member/member_list"; //출력 페이지로 포워딩
	}
	
	
	@RequestMapping("member/write.do")
	public String write() {
		return "member/write";
	}
	
	@ResponseBody
	@RequestMapping("member/insert.do")
	public String insert(@ModelAttribute MemberDTO dto) { //ModelAttribute 생략 가능
		memberService.insertMember(dto);
		return "redirect:/member/list.do"; //목록 갱신
	}
	
	@RequestMapping("member/view.do")
	public String view(@RequestParam String userid, Model model) {
		logger.info("클릭한 아이디:" + userid);
		model.addAttribute("dto", memberService.viewMember(userid));
		return "member/view";
	}
	
	@RequestMapping("member/update.do")
	public String update(@ModelAttribute MemberDTO dto, Model model){
		boolean result = memberService.checkPw(dto.getUserid(), dto.getPasswd());
		logger.info("=======비밀번호 확인:" + result + "=============" );
		    
		if(result) {
			memberService.updateMember(dto);
			return "redirect:/member/list.do";
		} else {
			//가입일자가 지워지지 않도록 처리
			MemberDTO dto2 = memberService.viewMember(dto.getUserid());
			dto.setJoin_date(dto2.getJoin_date());
			model.addAttribute("dto", dto);
			model.addAttribute("message", "비밀번호가 일치하지 않습니다.");
			return "member/view";
		}
	}
	
	@RequestMapping("member/delete.do")
	public String delete(@RequestParam String userid, 
			@RequestParam String passwd, Model model) {
		boolean result = memberService.checkPw(userid, passwd);
		if(result) {
			//삭제 처리
			memberService.deleteMember(userid);
			//회원목록으로 이동
			return "redirect:/member/list.do";
		} else {
			//비번이 틀렸을 때
			model.addAttribute("message", "비밀번호가 일치하지 않습니다.");
			model.addAttribute("dto", memberService.viewMember(userid));
			return "member/view";
		}
	}
}
