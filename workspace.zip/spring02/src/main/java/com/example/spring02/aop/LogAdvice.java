package com.example.spring02.aop;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LogAdvice {
	private static final Logger logger = LoggerFactory.getLogger(LogAdvice.class);
//point cut - start point
//Before, After, Around
	
//	@Around(
//			"execution(* com.example.spring02.controller..*Controller.*(..))"
//			+ " or execution(* com.example.spring02.service..*Impl.*(..))"
//			+ " or execution(* com.example.spring02.model..dao.*Impl.*(..))"
//			)
	
	public Object logPrint(ProceedingJoinPoint joinPoint) throws Throwable{
		long start = System.currentTimeMillis();
		Object result = joinPoint.proceed(); //�������� ȣ�� ��ȭ �ķ� ����
		String type = joinPoint.getSignature().getDeclaringTypeName(); //ȣ���� Ŭ���� �̸�
		String name = "";
		if(type.indexOf("Controller") > -1) {
			name = "Controller \t: ";
		} else if (type.indexOf("Service") > -1) {
			name = "ServiceImpl \t: ";
		} else if (type.indexOf("DAO") > -1) {
			name = "DAOImple \t: "; 
		}
		//method name
		logger.info(name + type + "." + joinPoint.getSignature().getName() + "()");
		//Parameter
		logger.info(Arrays.toString(joinPoint.getArgs()));
		//haxsimlosic
		long end = System.currentTimeMillis();
		long time = end-start;
		logger.info("����ð�:" + time);
		return result; 
	}
}
