package com.example.spring02.service.admin;

import com.example.spring02.model.member.dto.MemberDTO;

public interface AdminService {
	public String loginCheck(MemberDTO dto);
}
