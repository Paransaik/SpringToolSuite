package com.example.spring02.controller.shop;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.spring02.model.shop.dto.CartDTO;
import com.example.spring02.service.shop.CartService;

@Controller
@RequestMapping("/shop/cart/*")
public class CartController {

	@Inject
	CartService cartService;
// 인터셉터 inset, list
	@RequestMapping("insert.do")
	public String insert(CartDTO dto, HttpSession session) { //�뙆�씪誘명꽣 �븞�뿉 @ModelAttribute �깮�왂
		//濡쒓렇�씤 �뿬遺� 泥댄겕�븯湲� �쐞�빐 �꽭�뀡�뿉 ���옣�맂 �븘�씠�뵒 �솗�씤
		String userid=(String)session.getAttribute("userid");
//		if(userid==null) { // 로그인 하지 않는 상태이면 로그인 화면으로 막음, 인터셉터
//			return "redirect:/member/login.do";
//		}
		dto.setUserid(userid);
		cartService.insert(dto); //�옣諛붽뎄�땲 �뀒�씠釉붿뿉 ���옣
		return "redirect:/shop/cart/list.do"; //�옣諛붽뎄�땲 紐⑸줉�쑝濡� �씠�룞
	}
	
	@RequestMapping("list.do")
	public ModelAndView list(HttpSession session, ModelAndView mav) {
		Map<String, Object> map = new HashMap<>();


		String userid = (String) session.getAttribute("userid");
		if(userid!=null) { // 濡쒓렇�씤�븳 寃쎌슦
			List<CartDTO> list = cartService.listCart(userid);
			// �옣諛붽뎄�땲 湲덉븸 �빀怨�
			int sumMoney = cartService.sumMoney(userid);
			// 3留뚯썝 �씠�긽�씠硫� 諛곗넚猷� 硫댁젣
			int fee = sumMoney >= 30000? 0 : 2500;
			map.put("sumMoney", sumMoney);
			map.put("fee", fee);
			map.put("sum", sumMoney + fee);
			map.put("list", list); // �옣諛붽뎄�땲 紐⑸줉
			map.put("count", list.size()); // �젅肄붾뱶 媛쒖닔
			mav.setViewName("shop/cart_list"); // 酉곗쓽 �씠由�"
			mav.addObject("map", map); // 酉곗뿉 �쟾�떖�븷 �뜲�씠�꽣
			return mav; // cart_list.jsp濡� �룷�썙�뵫
		} else { // 로그인 하지 않는 상태, 인터셉터로 막음
			//return new ModelAndView("member/login", "", null);
			return null;
		}
	}
	
	@RequestMapping("delete.do")
	public String delete(@RequestParam int cart_id) {
		cartService.delete(cart_id);
		return "redirect:/shop/cart/list.do";
	}
	
	@RequestMapping("deleteAll.do")
	public String deleteAll(HttpSession session) {
		String userid=(String)session.getAttribute("userid");
		if(userid!=null) {
			cartService.deleteAll(userid);
		}
		return "redirect:/shop/cart/list.do";
	}
	
	@RequestMapping("update.do")
	public String update(int[] amount, int[] cart_id, HttpSession session) {
		String userid=(String)session.getAttribute("userid");
		for(int i=0; i<cart_id.length; i++) {
			if(amount[i]==0) {
				cartService.delete(cart_id[i]);
			} else {
				CartDTO dto=new CartDTO();
				dto.setUserid(userid);
				dto.setCart_id(cart_id[i]);
				dto.setAmount(amount[i]);
				cartService.modifyCart(dto);
			}
		}
		return "redirect:/shop/cart/list.do";
	}
}