package com.example.spring02.controller.upload;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class ImageUploadController {
/*
	private static final Logger logger=
	         LoggerFactory.getLogger(ImageUploadController.class);
*/
	@ResponseBody
	@RequestMapping("imageUpload.do")
	public void imageUpload(HttpServletRequest request, 
			HttpServletResponse response, 
			@RequestParam MultipartFile upload) throws Exception{
		//http header option
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		//http body option
		//���ε��� ���� �̸�
		String fileName=upload.getOriginalFilename();
		//����Ʈ ���Ϸ� ����
		byte[] bytes=upload.getBytes();
		//�̹����� ���ε��� ���丮(���� ��η� ����)
		String uploadPath = 
"F:\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\wtpwebapps\\spring02\\WEB-INF\\views\\images\\";
		OutputStream out=new FileOutputStream(new File(uploadPath+fileName)); //java.io
		//save in server
		out.write(bytes);
		String callback=request.getParameter("CKEditorFuncNum");
		PrintWriter printWriter=response.getWriter();
		String fileUrl=request.getContextPath()+"/images/"+fileName;
		System.out.println("fileUrl:"+fileUrl);
		printWriter.println("<script>window.parent.CKEDITOR.tools.callFunction("+callback+", '"+fileUrl+"','�̹����� ���ε� �Ǿ����ϴ�.')" + "</script>");
		printWriter.flush();
		out.close();
	}
}
