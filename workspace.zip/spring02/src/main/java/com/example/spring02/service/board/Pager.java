package com.example.spring02.service.board;

public class Pager {
	public static final int PAGE_SCALE=10; // �������� �Խù� ��
	public static final int BLOCK_SCALE=10; // ȭ��� ������ ��
	private int curPage; //hyeon jae page
	private int prevPage; // e jeong page
	private int nextPage; // da um page
	private int totPage; // jeon chae Page su
	private int totBlock; // jeon chae Page block su
	private int curBlock;
	private int prevBlock;
	private int nextBlock;
	//where rn between #{start} and #{end}
	private int pageBegin; //#{start}
	private int pageEnd; //#{end}
	//[����] blockBegin 42 43 44 45 46 47 48 blockEnd [����]
	private int blockBegin; //hyeon jae page bolck start numbmer
	private int blockEnd; //hyeon jae page bolck end numbmer
	
	public Pager(int count, int curPage) {
		curBlock = 1; //���� ������ ���� ��ȣ
		this.curPage = curPage; // ���� ������ ����
		setTotPage(count); //��ü ������ ���� ���
		setPageRange();
		setTotBlock();
		setBlockRange();
	}
	
	public void setPageRange() { //
		pageBegin=(curPage-1)*PAGE_SCALE+1;
		pageEnd=pageBegin + PAGE_SCALE-1;
	}

	public void setBlockRange() { //
		curBlock = (int)Math.ceil((curPage-1)/BLOCK_SCALE)+1;
		blockBegin=(curBlock-1)*BLOCK_SCALE+1;
		blockEnd=blockBegin+BLOCK_SCALE-1;
		if(blockEnd > totPage) blockEnd=totPage;
		prevPage=(curBlock == 1 ) ? 1 : (curBlock-1)*BLOCK_SCALE;
		nextPage=curBlock>totBlock ? (curBlock*BLOCK_SCALE) : (curBlock*BLOCK_SCALE)+1;
		if(nextPage>=totPage) nextPage = totPage;
	}
		
	public int getCurPage() { //
		return curPage;
	}
	public void setCurPage(int curPage) { //
		this.curPage = curPage;
	}
	public int getPrevPage() { //
		return prevPage;
	}
	public void setPrevPage(int prevPage) { //
		this.prevPage = prevPage;
	}
	public int getNextPage() { //
		return nextPage;
	}
	public void setNextPage(int nextPage) { //
		this.nextPage = nextPage;
	}
	public int getTotPage() { //
		return totPage;
	}
	public void setTotPage(int count) { //
		//Math.ceil(�Ǽ�) �ø� ó��
		totPage = (int)Math.ceil(count*1.0/PAGE_SCALE);
	}
	public int getTotBlock() { //
		return totBlock;
	}
	
	//page block for number count(ex: all 100 page = 10 block)
	public void setTotBlock() { //
		totBlock = (int)Math.ceil(totPage/BLOCK_SCALE);
	}
	public int getCurBlock() { //
		return curBlock;
	}
	public void setCurBlock(int curBlock) { //
		this.curBlock = curBlock;
	}
	public int getPrevBlock() {
		return prevBlock;
	}
	public void setPrevBlock(int prevBlock) {
		this.prevBlock = prevBlock;
	}
	public int getNextBlock() {
		return nextBlock;
	}
	public void setNextBlock(int nextBlock) {
		this.nextBlock = nextBlock;
	}
	public int getPageBegin() {
		return pageBegin;
	}
	public void setPageBegin(int pageBegin) {
		this.pageBegin = pageBegin;
	}
	public int getPageEnd() {
		return pageEnd;
	}
	public void setPageEnd(int pageEnd) {
		this.pageEnd = pageEnd;
	}
	public int getBlockBegin() {
		return blockBegin;
	}
	public void setBlockBegin(int blockBegin) { //
		this.blockBegin = blockBegin;
	}
	public int getBlockEnd() { //
		return blockEnd;
	}
	public void setBlockEnd(int blockEnd) { //
		this.blockEnd = blockEnd;
	}
	public static int getPageScale() {
		return PAGE_SCALE;
	}
	public static int getBlockScale() {
		return BLOCK_SCALE;
	}
}
