package com.example.spring02.model.shop.dao;

import java.util.List;

import com.example.spring02.model.shop.dto.CartDTO;

public interface CartDAO {
	List<CartDTO> cartMoney();
	void insert(CartDTO dto); //�옣諛붽뎄�땲 異붽�
	List<CartDTO> listCart(String userid); //�옣諛붽뎄�땲 紐⑸줉 
	void delete(int cart_id); //�옣諛붽뎄�땲 媛쒕퀎 �궘�젣
	void deleteAll(String userid); // �옣諛붽뎄�땲 鍮꾩슦湲�
	void update(int cart_id);
	int sumMoney(String userid); //�옣諛붽뎄�땲 湲덉븸 �빀怨�
	int countCart(String userid, int product_id); //�옣諛붽뎄�땲 �긽�뭹 媛쒖닔
	void updateCart(CartDTO dto); //�옣諛붽뎄�땲 �닔�젙
	void modifyCart(CartDTO dto);
}
