package com.example.spring05.model.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.example.spring05.model.dto.AnswerDTO;
import com.example.spring05.model.dto.SurveyDTO;

@Repository //dao bean
public class SurveyDAOImpl implements SurveyDAO {

	@Inject //�������� ����(DI)
	SqlSession sqlSession;
	
	@Override
	public SurveyDTO showSurvey(int survey_idx) {
		return sqlSession.selectOne("show_survey", survey_idx);
	}

	@Override
	public void save(AnswerDTO dto) {
		sqlSession.insert("save_answer", dto);
	}

	@Override
	public List<AnswerDTO> showResult(int survey_idx) {
		return sqlSession.selectList("show_result", survey_idx);
	}

}
